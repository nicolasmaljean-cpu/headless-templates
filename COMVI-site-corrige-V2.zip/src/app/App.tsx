import { BrowserRouter, Route, Routes } from "react-router-dom";
import { HomePage } from "./pages/HomePage";
import { RealisationsPage } from "./pages/RealisationsPage";
import { ScrollToHash } from "./components/ScrollToHash";
import { RevealManager } from "./components/RevealManager";

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToHash />
      <RevealManager />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/realisations" element={<RealisationsPage />} />
      </Routes>
    </BrowserRouter>
  );
}
