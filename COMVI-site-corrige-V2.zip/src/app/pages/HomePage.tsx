import { Header } from "../components/Header";
import { Hero } from "../components/Hero";
import { Services } from "../components/Services";
import { Work } from "../components/Work";
import { CaseStudies } from "../components/CaseStudies";
import { Testimonials } from "../components/Testimonials";
import { Configurator } from "../components/Configurator";
import { TargetAudience } from "../components/Target";
import { Pricing } from "../components/Pricing";
import { Process } from "../components/Process";
import { FAQSection } from "../components/FAQ";
import { CTA } from "../components/CTA";
import { Footer } from "../components/Footer";

export function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main id="main">
        <Hero />

        <div id="services">
          <Services />
        </div>

        {/* Preview on home – page dédiée /realisations */}
        <div id="realisations">
          <Work variant="preview" />
        </div>

        <CaseStudies />
        <Testimonials />
        <Configurator />

        <div id="target">
          <TargetAudience />
        </div>

        <div id="pack">
          <Pricing />
        </div>

        <div id="process">
          <Process />
        </div>

        <div id="faq">
          <FAQSection />
        </div>

        <div id="contact">
          <CTA />
        </div>
      </main>
      <Footer />
    </div>
  );
}
