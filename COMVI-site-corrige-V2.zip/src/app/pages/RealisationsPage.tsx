import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Work } from "../components/Work";
import { CTA } from "../components/CTA";
import { Button } from "../components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export function RealisationsPage() {
  return (
    <div className="min-h-screen">
      <Header variant="realisations" />
      <main id="main" className="pt-16">
        <section className="bg-gradient-to-b from-[#1a1a1a] via-[#141414] to-[#0f0f0f] text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-6">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <Button asChild variant="ghost" className="text-white hover:bg-white/10">
                  <Link to={{ pathname: "/", hash: "#realisations" }} className="inline-flex items-center gap-2">
                    <ArrowLeft className="w-4 h-4" />
                    Retour
                  </Link>
                </Button>

                <Button asChild className="bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
                  <Link to={{ pathname: "/", hash: "#contact" }}>Démarrer un projet</Link>
                </Button>
              </div>

              <div>
                <h1 data-reveal className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight">
                  Réalisations
                </h1>
                <p data-reveal data-reveal-delay="80" className="text-slate-300 max-w-3xl mt-4 text-lg">
                  Exemples concrets de contenus vidéo pensés pour convertir : hook, rythme, sous-titres, déclinaisons.
                  Tout ce que votre audience consomme — et ce qui vous rend mémorable localement.
                </p>
              </div>
            </div>
          </div>
        </section>

        <Work variant="full" />

        <div id="contact">
          <CTA />
        </div>
      </main>
      <Footer />
    </div>
  );
}
