import { useMemo, useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Link } from "react-router-dom";

type Persona = "commerce" | "pme" | "indep";
type Objective = "visibilite" | "regulier" | "recrutement" | "lancement";
type Pace = "light" | "regular" | "intense";

type Recommendation = {
  label: string;
  badge: string;
  points: string[];
};

export function Configurator() {
  const [persona, setPersona] = useState<Persona | null>(null);
  const [objective, setObjective] = useState<Objective | null>(null);
  const [pace, setPace] = useState<Pace | null>(null);

  const reco = useMemo<Recommendation | null>(() => {
    if (!persona || !objective || !pace) return null;

    if (pace === "regular") {
      return {
        label: "Pack Complet (abonnement mensuel)",
        badge: "Le plus choisi",
        points: [
          "Cadence stable + contenu réutilisable",
          "Réseaux + formats courts prêts à publier",
          "Pilotage clair : vous validez, on exécute",
        ],
      };
    }

    if (pace === "light") {
      return {
        label: "Pack Essentiel",
        badge: "Démarrage",
        points: [
          "Contenu régulier, léger, mais pro",
          "Formats courts + déclinaisons",
          "Idéal pour lancer la machine",
        ],
      };
    }

    return {
      label: "Pack Intensif (sur-mesure)",
      badge: "Accélération",
      points: [
        "Plus de contenus + vitesse de production",
        "Idéal lancement / promo / recrutement",
        "Organisation + process plus serré",
      ],
    };
  }, [persona, objective, pace]);

  return (
    <section className="py-24 bg-[#1a1a1a] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h2 data-reveal className="mb-3">Trouvez votre formule en 20 secondes</h2>
          <p data-reveal data-reveal-delay="70" className="text-slate-300 max-w-2xl">
            Le but : vous projeter vite. Vous choisissez votre profil et votre objectif, on vous propose une base.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <Card data-reveal data-reveal-delay="110" className="lg:col-span-3 bg-white/5 border-white/10 text-white p-6 rounded-2xl">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-slate-300">Votre activité</label>
                <Select onValueChange={(v) => setPersona(v as Persona)}>
                  <SelectTrigger className="mt-2 bg-white/5 border-white/15 text-white">
                    <SelectValue placeholder="Choisir" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="commerce">Commerce local</SelectItem>
                    <SelectItem value="pme">PME</SelectItem>
                    <SelectItem value="indep">Indépendant</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-slate-300">Objectif</label>
                <Select onValueChange={(v) => setObjective(v as Objective)}>
                  <SelectTrigger className="mt-2 bg-white/5 border-white/15 text-white">
                    <SelectValue placeholder="Choisir" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="visibilite">Visibilité locale</SelectItem>
                    <SelectItem value="regulier">Contenu régulier</SelectItem>
                    <SelectItem value="recrutement">Recrutement</SelectItem>
                    <SelectItem value="lancement">Lancement / promo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-slate-300">Rythme</label>
                <Select onValueChange={(v) => setPace(v as Pace)}>
                  <SelectTrigger className="mt-2 bg-white/5 border-white/15 text-white">
                    <SelectValue placeholder="Choisir" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Léger</SelectItem>
                    <SelectItem value="regular">Régulier</SelectItem>
                    <SelectItem value="intense">Intensif</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-6 rounded-xl border border-white/10 bg-black/20 p-4 text-slate-200 text-sm">
              <div className="font-medium text-white mb-2">Ce que vous obtenez</div>
              <ul className="space-y-1 list-disc pl-5">
                <li>Formats courts pensés mobile-first</li>
                <li>Sous-titres, rythme, hook : lisible sans le son</li>
                <li>Déclinaisons multi-plateformes</li>
              </ul>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <Button asChild className="bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
                <Link to={{ pathname: "/", hash: "#contact" }}>Recevoir une proposition</Link>
              </Button>
              <Button asChild variant="outline" className="border-white/20 text-white hover:bg-white/10">
                <Link to="/realisations">Voir des exemples</Link>
              </Button>
            </div>
          </Card>

          <Card data-reveal data-reveal-delay="170" className="lg:col-span-2 bg-white/5 border-white/10 text-white p-6 rounded-2xl">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h3 className="text-xl font-semibold">Recommandation</h3>
              {reco?.badge ? (
                <Badge className="bg-white/10 text-white border-white/15">{reco.badge}</Badge>
              ) : null}
            </div>

            {reco ? (
              <>
                <div className="text-white font-semibold mb-2">{reco.label}</div>
                <ul className="text-slate-200 text-sm space-y-2 list-disc pl-5 mb-6">
                  {reco.points.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
                <div className="text-slate-400 text-sm">
                  C’est une base. On ajuste selon vos objectifs, vos délais et votre contenu existant.
                </div>
              </>
            ) : (
              <div className="text-slate-300 text-sm">
                Sélectionnez 3 options pour afficher une recommandation.
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
}
