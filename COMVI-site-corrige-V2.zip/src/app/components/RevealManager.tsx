import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/**
 * Global, lightweight scroll-reveal.
 * Usage: add `data-reveal` on any element + optional `data-reveal-delay="80"` (ms)
 */
export function RevealManager() {
  const location = useLocation();

  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    if (!els.length) return;

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const el = entry.target as HTMLElement;
          el.classList.add("is-inview");
          io.unobserve(el);
        }
      },
      { root: null, threshold: 0.18, rootMargin: "0px 0px -10% 0px" }
    );

    for (const el of els) {
      const delay = el.getAttribute("data-reveal-delay");
      if (delay && !Number.isNaN(Number(delay))) {
        el.style.setProperty("--reveal-delay", `${Number(delay)}ms`);
      }
      io.observe(el);
    }

    return () => io.disconnect();
  }, [location.pathname]);

  return null;
}
