import { useState } from "react";
import { Button } from "./ui/button";
import { ArrowRight, Play } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Logo } from "./Logo";
import { Link } from "react-router-dom";

const SHOWREEL_MP4 = "/videos/showreel.mp4";
const SHOWREEL_POSTER = "/work/showreel-poster.svg";

export function Hero() {
  const [open, setOpen] = useState(false);

  return (
    <section className="relative min-h-screen flex items-center bg-gradient-to-br from-[#1a1a1a] via-[#2a2a2a] to-[#1a1a1a]">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?auto=format&fit=crop&w=1920&q=70"
          alt=""
          className="w-full h-full object-cover opacity-15"
          loading="lazy"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#1a1a1a]/60 to-[#1a1a1a]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <div className="mb-8" data-reveal>
          <Logo variant="full" alt="COMVI" className="h-20 sm:h-24 mx-auto mb-6" />
        </div>

        <h1
          data-reveal
          data-reveal-delay="60"
          className="mb-6 text-white max-w-5xl mx-auto text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight"
        >
          Contenu vidéo + marketing digital qui génère des résultats
        </h1>

        <p data-reveal data-reveal-delay="100" className="mb-10 text-slate-300 max-w-2xl mx-auto text-lg leading-relaxed">
          Agence de communication à Charleroi spécialisée en vidéo et marketing digital.
          On booste votre visibilité locale avec du contenu pro, sans que vous y passiez vos semaines.
        </p>

        <div data-reveal data-reveal-delay="140" className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button asChild size="lg" className="bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a] gap-2">
            <Link to={{ pathname: "/", hash: "#contact" }}>
              Démarrer un projet
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>

          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 gap-2">
                <Play className="w-4 h-4" />
                Voir le showreel
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl bg-[#0f0f0f] border-white/10">
              <DialogHeader>
                <DialogTitle className="text-white">Showreel COMVI</DialogTitle>
              </DialogHeader>
              <div className="aspect-video w-full overflow-hidden rounded-lg border border-white/10">
                <video
                  className="w-full h-full"
                  controls
                  playsInline
                  preload="none"
                  poster={SHOWREEL_POSTER}
                >
                  {open ? <source src={SHOWREEL_MP4} type="video/mp4" /> : null}
                </video>
              </div>
              <p className="text-slate-400 text-sm">
                Remplacez le fichier <span className="text-slate-200">/public/videos/showreel.mp4</span> par votre showreel.
              </p>
            </DialogContent>
          </Dialog>

          <Button asChild size="lg" variant="ghost" className="text-white hover:bg-white/10">
            <Link to="/realisations">Voir nos réalisations</Link>
          </Button>
        </div>

        {/* Quick proof cards */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div data-reveal data-reveal-delay="200" className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-colors">
            <div className="text-[#cfc7bc] mb-2 font-medium">10 vidéos / mois</div>
            <div className="text-white/80">Production régulière</div>
          </div>
          <div data-reveal data-reveal-delay="240" className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-colors">
            <div className="text-[#cfc7bc] mb-2 font-medium">PME & commerces</div>
            <div className="text-white/80">Stratégie locale</div>
          </div>
          <div data-reveal data-reveal-delay="280" className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-colors">
            <div className="text-[#cfc7bc] mb-2 font-medium">Réseau de talents</div>
            <div className="text-white/80">Réactivité + flexibilité</div>
          </div>
        </div>
      </div>
    </section>
  );
}
