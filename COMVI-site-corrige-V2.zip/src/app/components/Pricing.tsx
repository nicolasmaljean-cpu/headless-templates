import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Check } from "lucide-react";
import { Link } from "react-router-dom";

export function Pricing() {
  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 data-reveal className="mb-4">Pack Complet</h2>
          <p data-reveal data-reveal-delay="70" className="text-slate-600 max-w-2xl mx-auto">
            Tout ce qu'il faut pour une communication régulière, pro et visible. Sans vous prendre la tête.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card data-reveal data-reveal-delay="110" className="p-8 border-2 border-[#cfc7bc]/20 shadow-xl">
            <div className="mb-6">
              <div className="inline-block px-4 py-2 bg-[#cfc7bc]/20 text-[#1a1a1a] rounded-full mb-4">
                Abonnement mensuel
              </div>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-[#1a1a1a]/70">À partir de</span>
                <span className="text-slate-900">1 000 €</span>
                <span className="text-slate-600">/ mois</span>
              </div>
              <p className="text-slate-600">
                Le prix varie selon vos besoins spécifiques et la complexité des projets.
              </p>
            </div>

            <div className="border-t border-slate-200 pt-6 mb-8">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-[#cfc7bc]/20 rounded-full flex items-center justify-center mt-1">
                    <Check className="w-4 h-4 text-[#1a1a1a]" />
                  </div>
                  <div>
                    <div className="text-slate-900">10 snack contents / mois</div>
                    <div className="text-slate-600">Vidéos courtes optimisées pour l'attention et la rétention</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-[#cfc7bc]/20 rounded-full flex items-center justify-center mt-1">
                    <Check className="w-4 h-4 text-[#1a1a1a]" />
                  </div>
                  <div>
                    <div className="text-slate-900">10 visuels / mois</div>
                    <div className="text-slate-600">Posts, stories, carrousels adaptés à vos réseaux</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-[#cfc7bc]/20 rounded-full flex items-center justify-center mt-1">
                    <Check className="w-4 h-4 text-[#1a1a1a]" />
                  </div>
                  <div>
                    <div className="text-slate-900">Suivi réseaux sociaux</div>
                    <div className="text-slate-600">Gestion, planification et cohérence garanties</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-[#cfc7bc]/20 rounded-full flex items-center justify-center mt-1">
                    <Check className="w-4 h-4 text-[#1a1a1a]" />
                  </div>
                  <div>
                    <div className="text-slate-900">1 action RP / mois</div>
                    <div className="text-slate-600">Communiqué de presse, relation média, visibilité locale</div>
                  </div>
                </div>
              </div>
            </div>

            <Button asChild className="w-full bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
              <Link to={{ pathname: "/", hash: "#contact" }}>Discuter de mon projet</Link>
            </Button>

            <p className="text-center text-slate-600 mt-4">
              On adapte le pack à vos objectifs et votre budget
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
}