import { Store, Briefcase, Users, Target } from "lucide-react";

export function TargetAudience() {
  return (
    <section className="py-24 bg-gradient-to-br from-[#1a1a1a] to-[#2a2a2a] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="mb-4 text-white">Pour qui on travaille</h2>
          <p className="text-slate-300 max-w-2xl mx-auto">
            On accompagne les PME, indépendants et commerces de proximité qui veulent gagner en visibilité sans perdre leur temps.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8">
            <Store className="w-12 h-12 text-[#cfc7bc] mb-4" />
            <h3 className="mb-3 text-white">Commerces de proximité</h3>
            <p className="text-slate-300 mb-4">
              Restaurants, boutiques, salons, services locaux qui veulent se démarquer et attirer plus de clients dans leur zone.
            </p>
            <div className="text-[#cfc7bc]">→ Visibilité locale maximale</div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8">
            <Briefcase className="w-12 h-12 text-[#cfc7bc] mb-4" />
            <h3 className="mb-3 text-white">PME & indépendants</h3>
            <p className="text-slate-300 mb-4">
              Entrepreneurs, consultants, entreprises en croissance qui ont besoin d'une communication pro sans embaucher une équipe dédiée.
            </p>
            <div className="text-[#cfc7bc]">→ Image crédible + gain de temps</div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8">
          <div className="flex items-start gap-6 mb-6">
            <Target className="w-12 h-12 text-[#cfc7bc] flex-shrink-0" />
            <div>
              <h3 className="mb-3 text-white">Vous vous reconnaissez si...</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <span className="text-[#cfc7bc] mt-1">✓</span>
                  <span className="text-slate-300">Vous voulez plus de visibilité locale</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#cfc7bc] mt-1">✓</span>
                  <span className="text-slate-300">Vous n'avez pas le temps de gérer la com' vous-même</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#cfc7bc] mt-1">✓</span>
                  <span className="text-slate-300">Vous voulez du contenu régulier et pro</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#cfc7bc] mt-1">✓</span>
                  <span className="text-slate-300">Vous cherchez des résultats concrets, pas du blabla</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#cfc7bc] mt-1">✓</span>
                  <span className="text-slate-300">Vous voulez déléguer en gardant le contrôle</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#cfc7bc] mt-1">✓</span>
                  <span className="text-slate-300">Vous ciblez principalement le marché belge</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}