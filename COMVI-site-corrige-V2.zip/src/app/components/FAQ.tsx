import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";

const FAQ = [
  {
    q: "Combien de temps faut-il pour voir les premiers contenus ?",
    a: "Dès qu’on a votre brief (objectif, cible, identité visuelle), on cale la prod et on sort les premiers formats rapidement. Le rythme dépend du volume choisi et des validations.",
  },
  {
    q: "Comment se passe la validation ?",
    a: "Vous validez sur des versions courtes et claires. L’objectif : garder le contrôle sans y passer votre semaine.",
  },
  {
    q: "Vous vous déplacez ?",
    a: "Oui. Tournage sur site selon vos besoins (Charleroi et alentours, et plus loin si nécessaire).",
  },
  {
    q: "Est-ce que vous fournissez aussi des visuels ?",
    a: "Oui, selon la formule : déclinaisons posts/stories/carrousels pour accompagner la vidéo et maintenir une cohérence de marque.",
  },
  {
    q: "On a déjà du contenu (photos/vidéos). Vous pouvez l’exploiter ?",
    a: "Oui. On peut recycler et optimiser l’existant, puis compléter avec du contenu tourné sur mesure.",
  },
];

export function FAQSection() {
  return (
    <section className="py-24 bg-[#121212] text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10 text-center">
          <h2 className="mb-3">FAQ</h2>
          <p className="text-slate-300">
            Les questions classiques avant de démarrer. On garde ça simple.
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full">
          {FAQ.map((item, idx) => (
            <AccordionItem key={idx} value={`item-${idx}`} className="border-white/10">
              <AccordionTrigger className="text-left text-white hover:no-underline">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="text-slate-300">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
