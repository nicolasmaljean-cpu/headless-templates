import { Video, TrendingUp, Newspaper, Radio, Users } from "lucide-react";
import { Card } from "./ui/card";

const services = [
  {
    icon: Video,
    title: "Vidéo",
    subtitle: "Cœur d'offre",
    description: "Snack content, vidéos de marque, présentation, coulisses, témoignages, recrutement, évènementiel.",
    benefits: [
      "Plus de visibilité",
      "Image plus crédible",
      "Contenu régulier sans y passer vos semaines",
      "Système de contenu réutilisable en plusieurs formats"
    ],
    color: "purple"
  },
  {
    icon: TrendingUp,
    title: "Marketing digital",
    subtitle: "Sans partir sur du technique",
    description: "Stratégie de contenu, ligne éditoriale, storytelling, gestion réseaux sociaux, optimisation de présence digitale.",
    benefits: [
      "Communication claire et régulière",
      "Stratégie pilotée, pas 'au feeling'",
      "Cohérence de marque garantie",
      "Cadence et cohérence sur vos réseaux"
    ],
    color: "blue"
  },
  {
    icon: Newspaper,
    title: "Relations presse",
    subtitle: "Visibilité médiatique",
    description: "Rédaction et diffusion de communiqués, angles médias, calendrier de prises de parole.",
    benefits: [
      "Crédibilité renforcée",
      "Visibilité 'hors réseaux'",
      "Image plus institutionnelle",
      "Couverture médiatique ciblée"
    ],
    color: "green"
  },
  {
    icon: Radio,
    title: "Diffusion médias locaux",
    subtitle: "TV & Presse régionale",
    description: "Achat et diffusion de campagnes via TéléSambre, L'Avenir, La DH. TV locale + presse écrite régionale.",
    benefits: [
      "Notoriété locale rapide",
      "Touche 'grand public'",
      "Légitimité immédiate",
      "Impact mesurable"
    ],
    color: "orange"
  },
  {
    icon: Users,
    title: "Talents à la mission",
    subtitle: "Modèle hybride",
    description: "Mise à disposition de talents (étudiants/indépendants) pour exécuter contenu, com' et support opérationnel. COMVI pilote qualité et coordination.",
    benefits: [
      "Flexibilité maximale",
      "Vitesse d'exécution",
      "Budget mieux contrôlé",
      "Ressources adaptées à vos besoins"
    ],
    color: "pink"
  }
];

const colorClasses: Record<string, { bg: string; text: string; border: string }> = {
  purple: { bg: "bg-[#cfc7bc]/10", text: "text-[#1a1a1a]", border: "border-[#cfc7bc]/20" },
  blue: { bg: "bg-[#cfc7bc]/10", text: "text-[#1a1a1a]", border: "border-[#cfc7bc]/20" },
  green: { bg: "bg-[#cfc7bc]/10", text: "text-[#1a1a1a]", border: "border-[#cfc7bc]/20" },
  orange: { bg: "bg-[#cfc7bc]/10", text: "text-[#1a1a1a]", border: "border-[#cfc7bc]/20" },
  pink: { bg: "bg-[#cfc7bc]/10", text: "text-[#1a1a1a]", border: "border-[#cfc7bc]/20" }
};

export function Services() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 data-reveal className="mb-4">Ce qu'on fait pour vous</h2>
          <p data-reveal data-reveal-delay="70" className="text-slate-600 max-w-2xl mx-auto">
            5 expertises pour booster votre communication, votre visibilité et vos résultats. Du concret, pas du blabla.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            const colors = colorClasses[service.color];
            
            return (
              <Card
                key={index}
                className={`p-6 border-2 ${colors.border} hover:shadow-lg transition-shadow`}
                data-reveal
                data-reveal-delay={String(90 + index * 60)}
              >
                <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className={`w-6 h-6 ${colors.text}`} />
                </div>
                
                <h3 className="mb-1">{service.title}</h3>
                <p className={`mb-3 ${colors.text}`}>{service.subtitle}</p>
                <p className="text-slate-600 mb-4">{service.description}</p>
                
                <div className="space-y-2">
                  <div className={`${colors.text}`}>Bénéfices :</div>
                  <ul className="space-y-1">
                    {service.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start gap-2 text-slate-600">
                        <span className={`${colors.text} mt-1`}>•</span>
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}