import { useEffect, useMemo, useState } from "react";
import { Button } from "./ui/button";
import { Menu } from "lucide-react";
import { Sheet, SheetClose, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { Logo } from "./Logo";
import { Link, useLocation } from "react-router-dom";

type NavItem = { kind: "section"; id: string; label: string } | { kind: "page"; to: string; label: string };

function useScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const max = Math.max(1, doc.scrollHeight - doc.clientHeight);
      setProgress(doc.scrollTop / max);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return progress;
}

function useActiveSection(sectionIds: string[]) {
  const [active, setActive] = useState(sectionIds[0] ?? "");

  useEffect(() => {
    const els = sectionIds
      .map((id) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];

    if (!els.length) return;

    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => (b.intersectionRatio ?? 0) - (a.intersectionRatio ?? 0))[0];

        if (visible?.target?.id) setActive(visible.target.id);
      },
      { root: null, threshold: [0.2, 0.35, 0.5, 0.65] }
    );

    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [sectionIds]);

  return active;
}

export function Header({ variant }: { variant?: "default" | "realisations" } = { variant: "default" }) {
  const location = useLocation();
  const isHome = location.pathname === "/";

  const nav = useMemo<NavItem[]>(
    () => [
      { kind: "section", id: "services", label: "Services" },
      { kind: "page", to: "/realisations", label: "Réalisations" },
      { kind: "section", id: "pack", label: "Pack" },
      { kind: "section", id: "process", label: "Process" },
      { kind: "section", id: "faq", label: "FAQ" },
      { kind: "section", id: "contact", label: "Contact" },
    ],
    []
  );

  const progress = useScrollProgress();
  const sections = nav.filter((n): n is Extract<NavItem, { kind: "section" }> => n.kind === "section");
  const active = useActiveSection(sections.map((n) => n.id));

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#1a1a1a]/95 backdrop-blur-sm border-b border-white/10">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 bg-white text-[#1a1a1a] px-4 py-2 rounded-md"
      >
        Aller au contenu
      </a>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Link to={{ pathname: "/", hash: "#main" }} className="flex items-center gap-3">
              <Logo variant="mark" alt="COMVI" className="h-10 w-10" />
              <span className="text-white font-semibold tracking-tight hidden sm:inline">COMVI</span>
            </Link>
          </div>

          {/* Navigation desktop */}
          <nav className="hidden md:flex items-center gap-8">
            {nav.map((item) => {
              if (item.kind === "page") {
                const isActive = location.pathname === item.to;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={["transition-colors text-sm", isActive ? "text-white" : "text-slate-300 hover:text-white"].join(
                      " "
                    )}
                  >
                    {item.label}
                  </Link>
                );
              }

              return (
                <Link
                  key={item.id}
                  to={{ pathname: "/", hash: `#${item.id}` }}
                  className={[
                    "transition-colors text-sm",
                    isHome && active === item.id ? "text-white" : "text-slate-300 hover:text-white",
                  ].join(" ")}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* CTA + Mobile */}
          <div className="flex items-center gap-3">
            <Button asChild className="hidden sm:inline-flex bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
              <Link to={{ pathname: "/", hash: "#contact" }}>Démarrer un projet</Link>
            </Button>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden text-white">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-[#121212] border-white/10 text-white">
                <SheetHeader>
                  <SheetTitle className="text-white">Navigation</SheetTitle>
                </SheetHeader>

                <div className="mt-6 flex flex-col gap-2">
                  {nav.map((item) => {
                    if (item.kind === "page") {
                      return (
                        <SheetClose asChild key={item.to}>
                          <Link to={item.to} className="px-4 py-3 rounded-lg hover:bg-white/10 transition-colors">
                            {item.label}
                          </Link>
                        </SheetClose>
                      );
                    }

                    return (
                      <SheetClose asChild key={item.id}>
                        <Link
                          to={{ pathname: "/", hash: `#${item.id}` }}
                          className="px-4 py-3 rounded-lg hover:bg-white/10 transition-colors"
                        >
                          {item.label}
                        </Link>
                      </SheetClose>
                    );
                  })}

                  <div className="mt-4">
                    <SheetClose asChild>
                      <Button asChild className="w-full bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
                        <Link to={{ pathname: "/", hash: "#contact" }}>Démarrer un projet</Link>
                      </Button>
                    </SheetClose>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Scroll progress */}
      <div className="h-[2px] w-full bg-white/5">
        <div className="h-full bg-[#cfc7bc]" style={{ width: `${Math.round(progress * 100)}%` }} />
      </div>
    </header>
  );
}
