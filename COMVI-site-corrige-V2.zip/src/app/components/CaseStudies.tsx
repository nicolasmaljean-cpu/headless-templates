import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Link } from "react-router-dom";

type CaseStudy = {
  title: string;
  sector: string;
  goal: string;
  whatWeDid: string[];
  results: string[];
};

const CASES: CaseStudy[] = [
  {
    title: "Restaurant (Charleroi) — remplir les services",
    sector: "Commerce local",
    goal: "Augmenter la fréquentation sur 4 semaines",
    whatWeDid: [
      "Série de snack contents (hooks + sous-titres)",
      "Déclinaisons stories + reels",
      "Coulisses + témoignage client",
    ],
    results: ["Plus de demandes en DM", "Trafic en magasin en hausse", "Contenu réutilisable pour les promos"],
  },
  {
    title: "PME B2B — devenir la référence locale",
    sector: "PME",
    goal: "Installer une image experte et régulière",
    whatWeDid: ["Plan éditorial", "Capsules expertise", "Posts LinkedIn + montage formats courts"],
    results: ["Positionnement plus clair", "Plus de prises de rendez-vous", "Meilleure cohérence de marque"],
  },
  {
    title: "Recrutement — attirer les bons profils",
    sector: "RH",
    goal: "Faire comprendre l’ambiance et le job",
    whatWeDid: ["Micro-interviews", "Visite des locaux", "Clips multi-formats"],
    results: ["Candidatures plus qualifiées", "Moins de “mauvais fit”", "Image employeur plus forte"],
  },
];

export function CaseStudies() {
  return (
    <section className="py-24 bg-gradient-to-b from-[#1a1a1a] to-[#121212] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h2 data-reveal className="mb-3">Cas clients</h2>
          <p data-reveal data-reveal-delay="70" className="text-slate-300 max-w-2xl">
            Format simple : objectif → actions → résultat. Le prospect comprend vite et se projette.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {CASES.map((c, idx) => (
            <Card
              key={c.title}
              className="bg-white/5 border-white/10 text-white p-6 rounded-2xl"
              data-reveal
              data-reveal-delay={String(90 + idx * 60)}
            >
              <div className="flex items-center justify-between gap-3 mb-4">
                <Badge className="bg-white/10 text-white border-white/15">{c.sector}</Badge>
                <span className="text-slate-400 text-sm">Objectif</span>
              </div>

              <h3 className="text-xl font-semibold mb-2">{c.title}</h3>
              <p className="text-slate-200 mb-5">{c.goal}</p>

              <div className="space-y-4">
                <div>
                  <div className="text-slate-400 text-sm mb-2">Ce qu’on fait</div>
                  <ul className="text-slate-200 text-sm space-y-1 list-disc pl-5">
                    {c.whatWeDid.map((w) => (
                      <li key={w}>{w}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <div className="text-slate-400 text-sm mb-2">Ce que ça change</div>
                  <ul className="text-slate-200 text-sm space-y-1 list-disc pl-5">
                    {c.results.map((r) => (
                      <li key={r}>{r}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-10 flex justify-center">
          <Button asChild className="bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
            <Link to={{ pathname: "/", hash: "#contact" }}>Je veux un plan similaire</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
