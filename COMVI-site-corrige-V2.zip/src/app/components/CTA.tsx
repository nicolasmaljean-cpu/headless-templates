import { useMemo, useState } from "react";
import { ArrowRight, Mail, Phone } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Link } from "react-router-dom";

type Brief = {
  activity: string;
  objective: string;
  name: string;
  email: string;
  phone: string;
  message: string;
};

const INITIAL: Brief = {
  activity: "",
  objective: "",
  name: "",
  email: "",
  phone: "",
  message: "",
};

export function CTA() {
  const [step, setStep] = useState<1 | 2>(1);
  const [brief, setBrief] = useState<Brief>(INITIAL);

  const canGoNext = useMemo(() => brief.activity && brief.objective, [brief.activity, brief.objective]);
  const canSend = useMemo(() => brief.name && brief.email, [brief.name, brief.email]);

  const mailto = useMemo(() => {
    const subject = encodeURIComponent("Brief — Projet COMVI");
    const body = encodeURIComponent(
      [
        `Activité: ${brief.activity || "-"}`,
        `Objectif: ${brief.objective || "-"}`,
        "",
        `Nom: ${brief.name || "-"}`,
        `Email: ${brief.email || "-"}`,
        `Téléphone: ${brief.phone || "-"}`,
        "",
        `Message:`,
        brief.message || "-",
      ].join("\n")
    );
    return `mailto:contact@comvi.be?subject=${subject}&body=${body}`;
  }, [brief]);

  return (
    <section className="py-24 bg-gradient-to-r from-[#cfc7bc] to-[#bfb7ac]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
          <div>
            <h2 data-reveal className="mb-4 text-[#1a1a1a]">Prêt à booster votre visibilité ?</h2>
            <p data-reveal data-reveal-delay="60" className="text-[#1a1a1a]/70 mb-8 max-w-xl">
              Dites-nous ce que vous visez. On revient avec une proposition simple, claire, et actionnable.
            </p>

            <div data-reveal data-reveal-delay="110" className="flex flex-col sm:flex-row gap-4 items-start mb-10">
              <Button asChild size="lg" className="bg-[#1a1a1a] text-white hover:bg-[#2a2a2a] gap-2">
                <a href={mailto} aria-label="Envoyer un email à COMVI">
                  Envoyer un brief
                  <ArrowRight className="w-4 h-4" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-[#1a1a1a] text-[#1a1a1a] hover:bg-[#1a1a1a]/10"
                asChild
              >
                <Link to={{ pathname: "/", hash: "#process" }}>Voir comment on bosse</Link>
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 items-start text-[#1a1a1a]/80">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                <span>contact@comvi.be</span>
              </div>
              <div className="hidden sm:block w-1 h-1 bg-[#1a1a1a]/50 rounded-full"></div>
              <div className="flex items-center gap-2">
                <Phone className="w-5 h-5" />
                <span>+32 XX XX XX XX</span>
              </div>
            </div>
          </div>

          <Card className="bg-white/70 backdrop-blur border-white/50 p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-6">
              <div className="text-[#1a1a1a] font-semibold">Brief rapide</div>
              <div className="text-[#1a1a1a]/60 text-sm">Étape {step}/2</div>
            </div>

            {step === 1 ? (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-[#1a1a1a]/80">Votre activité</label>
                  <Select onValueChange={(v) => setBrief((b) => ({ ...b, activity: v }))}>
                    <SelectTrigger className="mt-2 bg-white border-[#1a1a1a]/20 text-[#1a1a1a]">
                      <SelectValue placeholder="Choisir" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Commerce local">Commerce local</SelectItem>
                      <SelectItem value="PME">PME</SelectItem>
                      <SelectItem value="Indépendant">Indépendant</SelectItem>
                      <SelectItem value="Événementiel">Événementiel</SelectItem>
                      <SelectItem value="Autre">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm text-[#1a1a1a]/80">Votre objectif</label>
                  <Select onValueChange={(v) => setBrief((b) => ({ ...b, objective: v }))}>
                    <SelectTrigger className="mt-2 bg-white border-[#1a1a1a]/20 text-[#1a1a1a]">
                      <SelectValue placeholder="Choisir" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Visibilité locale">Visibilité locale</SelectItem>
                      <SelectItem value="Contenu régulier">Contenu régulier</SelectItem>
                      <SelectItem value="Recrutement">Recrutement</SelectItem>
                      <SelectItem value="Lancement / promo">Lancement / promo</SelectItem>
                      <SelectItem value="Événement">Événement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="pt-2 flex gap-3">
                  <Button
                    className="bg-[#1a1a1a] text-white hover:bg-[#2a2a2a]"
                    onClick={() => setStep(2)}
                    disabled={!canGoNext}
                  >
                    Continuer
                  </Button>
                  <Button
                    variant="ghost"
                    className="text-[#1a1a1a]"
                    onClick={() => setBrief(INITIAL)}
                  >
                    Réinitialiser
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-[#1a1a1a]/80">Nom</label>
                    <Input
                      className="mt-2 bg-white border-[#1a1a1a]/20 text-[#1a1a1a]"
                      value={brief.name}
                      onChange={(e) => setBrief((b) => ({ ...b, name: e.target.value }))}
                      placeholder="Votre nom"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-[#1a1a1a]/80">Téléphone (optionnel)</label>
                    <Input
                      className="mt-2 bg-white border-[#1a1a1a]/20 text-[#1a1a1a]"
                      value={brief.phone}
                      onChange={(e) => setBrief((b) => ({ ...b, phone: e.target.value }))}
                      placeholder="+32 …"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm text-[#1a1a1a]/80">Email</label>
                  <Input
                    type="email"
                    className="mt-2 bg-white border-[#1a1a1a]/20 text-[#1a1a1a]"
                    value={brief.email}
                    onChange={(e) => setBrief((b) => ({ ...b, email: e.target.value }))}
                    placeholder="vous@entreprise.be"
                  />
                </div>

                <div>
                  <label className="text-sm text-[#1a1a1a]/80">Message (optionnel)</label>
                  <Textarea
                    className="mt-2 bg-white border-[#1a1a1a]/20 text-[#1a1a1a] min-h-28"
                    value={brief.message}
                    onChange={(e) => setBrief((b) => ({ ...b, message: e.target.value }))}
                    placeholder="Contexte, timing, liens utiles…"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <Button
                    asChild
                    className="bg-[#1a1a1a] text-white hover:bg-[#2a2a2a] gap-2"
                    disabled={!canSend}
                  >
                    <a href={mailto}>
                      Envoyer
                      <ArrowRight className="w-4 h-4" />
                    </a>
                  </Button>

                  <Button variant="outline" className="border-[#1a1a1a]/30 text-[#1a1a1a]" onClick={() => setStep(1)}>
                    Retour
                  </Button>
                </div>

                <p className="text-xs text-[#1a1a1a]/60">
                  Envoi via votre client mail (aucune donnée stockée sur le site).
                </p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
}
