import { useMemo, useState } from "react";
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";
import { Play } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Link } from "react-router-dom";

type WorkItem = {
  id: string;
  title: string;
  sector: string;
  goal: string;
  tags: string[];
  poster: string;
  videoMp4?: string; // self-hosted (preferred)
  videoWebm?: string;
};

const ITEMS: WorkItem[] = [
  {
    id: "work-1",
    title: "Restaurant — lancement & visibilité locale",
    sector: "commerces",
    goal: "Remplir les services du week-end",
    tags: ["snack content", "instagram", "local"],
    poster: "/work/work-1.svg",
    videoMp4: "/videos/sample.mp4",
  },
  {
    id: "work-2",
    title: "Artisan — crédibilité & différenciation",
    sector: "commerces",
    goal: "Montrer le savoir-faire en 30 secondes",
    tags: ["storytelling", "coulisses", "branding"],
    poster: "/work/work-2.svg",
    videoMp4: "/videos/sample.mp4",
  },
  {
    id: "work-3",
    title: "PME B2B — contenu régulier & image pro",
    sector: "pme",
    goal: "Devenir la référence locale",
    tags: ["linkedin", "expertise", "régularité"],
    poster: "/work/work-3.svg",
    videoMp4: "/videos/sample.mp4",
  },
  {
    id: "work-4",
    title: "Événement — couverture + recap",
    sector: "events",
    goal: "Créer une preuve sociale immédiate",
    tags: ["event", "recap", "reels"],
    poster: "/work/work-4.svg",
    videoMp4: "/videos/sample.mp4",
  },
  {
    id: "work-5",
    title: "Recrutement — attirer les bons profils",
    sector: "recrutement",
    goal: "Faire comprendre l’ambiance et la mission",
    tags: ["recrutement", "témoignage", "culture"],
    poster: "/work/work-5.svg",
    videoMp4: "/videos/sample.mp4",
  },
  {
    id: "work-6",
    title: "Commerce — promo flash (48h)",
    sector: "commerces",
    goal: "Générer du trafic en magasin",
    tags: ["promo", "story", "local"],
    poster: "/work/work-6.svg",
    videoMp4: "/videos/sample.mp4",
  },
];

const FILTERS = [
  { key: "all", label: "Tout" },
  { key: "commerces", label: "Commerces" },
  { key: "pme", label: "PME" },
  { key: "events", label: "Événements" },
  { key: "recrutement", label: "Recrutement" },
] as const;

export function Work({ variant = "full" }: { variant?: "preview" | "full" }) {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["key"]>("all");
  const [openId, setOpenId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    if (filter === "all") return ITEMS;
    return ITEMS.filter((i) => i.sector === filter);
  }, [filter]);

  const visibleItems = useMemo(() => {
    const base = variant === "preview" ? filtered.slice(0, 6) : filtered;
    return base;
  }, [filtered, variant]);

  const openItem = useMemo(() => ITEMS.find((i) => i.id === openId) ?? null, [openId]);

  return (
    <section className="py-24 bg-[#1a1a1a] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-10">
          <div>
            <h2 data-reveal className="mb-3">Réalisations</h2>
            <p data-reveal data-reveal-delay="70" className="text-slate-300 max-w-2xl">
              {variant === "preview"
                ? "Un avant-goût de nos formats. Cliquez pour voir le détail, ou ouvrez la page dédiée."
                : "Des exemples concrets pour vous projeter. Remplacez les miniatures et les vidéos par vos projets."}
            </p>
          </div>

          <div data-reveal data-reveal-delay="120" className="flex flex-wrap gap-2">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={[
                  "px-4 py-2 rounded-full text-sm border transition-colors",
                  filter === f.key
                    ? "bg-[#cfc7bc] text-[#1a1a1a] border-[#cfc7bc]"
                    : "border-white/15 text-slate-200 hover:bg-white/10",
                ].join(" ")}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        <ResponsiveMasonry columnsCountBreakPoints={{ 350: 1, 768: 2, 1024: 3 }}>
          <Masonry gutter="16px">
            {visibleItems.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setOpenId(item.id)}
                className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 text-left focus:outline-none focus:ring-2 focus:ring-[#cfc7bc]"
                data-reveal
                data-reveal-delay={String(80 + Math.min(idx, 7) * 40)}
              >
                <img
                  src={item.poster}
                  alt={item.title}
                  className="w-full h-auto object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  loading="lazy"
                  decoding="async"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-90" />

                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="flex flex-wrap gap-2">
                      {item.tags.slice(0, 2).map((t) => (
                        <Badge key={t} className="bg-white/10 text-white border-white/15">
                          {t}
                        </Badge>
                      ))}
                    </div>
                    <div className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center">
                      <Play className="w-5 h-5 text-[#cfc7bc]" />
                    </div>
                  </div>
                  <div className="text-white font-semibold leading-snug">{item.title}</div>
                  <div className="text-slate-300 text-sm mt-1">Objectif : {item.goal}</div>
                </div>
              </button>
            ))}
          </Masonry>
        </ResponsiveMasonry>

        <div className="mt-10 flex justify-center gap-3 flex-wrap">
          {variant === "preview" ? (
            <>
              <Button asChild variant="outline" className="border-white/20 text-white hover:bg-white/10">
                <Link to="/realisations">Voir toutes les réalisations</Link>
              </Button>
              <Button asChild className="bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
                <Link to={{ pathname: "/", hash: "#contact" }}>Démarrer un projet</Link>
              </Button>
            </>
          ) : (
            <Button asChild variant="outline" className="border-white/20 text-white hover:bg-white/10">
              <Link to={{ pathname: "/", hash: "#contact" }}>Je veux ce style de contenu</Link>
            </Button>
          )}
        </div>

        <Dialog open={!!openItem} onOpenChange={(v) => !v && setOpenId(null)}>
          <DialogContent className="max-w-5xl bg-[#0f0f0f] border-white/10">
            <DialogHeader>
              <DialogTitle className="text-white">{openItem?.title}</DialogTitle>
            </DialogHeader>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              <div className="lg:col-span-3">
                {openItem?.videoMp4 || openItem?.videoWebm ? (
                  <div className="aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-black">
                    <video
                      key={openItem?.id}
                      className="w-full h-full"
                      controls
                      playsInline
                      preload="none"
                      poster={openItem?.poster}
                    >
                      {/* Lazy-load: sources only mounted when modal is open */}
                      {openItem?.videoWebm ? <source src={openItem.videoWebm} type="video/webm" /> : null}
                      {openItem?.videoMp4 ? <source src={openItem.videoMp4} type="video/mp4" /> : null}
                    </video>
                  </div>
                ) : (
                  <img
                    src={openItem?.poster}
                    alt={openItem?.title ?? ""}
                    className="w-full h-auto rounded-xl border border-white/10"
                  />
                )}
              </div>

              <div className="lg:col-span-2 space-y-4">
                <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                  <div className="text-slate-300 text-sm">Objectif</div>
                  <div className="text-white font-medium">{openItem?.goal}</div>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                  <div className="text-slate-300 text-sm mb-2">Format</div>
                  <ul className="text-slate-200 text-sm space-y-1 list-disc pl-5">
                    <li>Vidéo courte (mobile-first)</li>
                    <li>Hook rapide + sous-titres</li>
                    <li>Déclinaison multi-plateformes</li>
                  </ul>
                </div>

                <Button asChild className="w-full bg-[#cfc7bc] hover:bg-[#bfb7ac] text-[#1a1a1a]">
                  <Link to={{ pathname: "/", hash: "#contact" }}>Démarrer un projet similaire</Link>
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
