import { useEffect } from "react";
import { useLocation } from "react-router-dom";

const HEADER_OFFSET = 80;

function prefersReducedMotion() {
  return typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
}

export function ScrollToHash() {
  const location = useLocation();

  useEffect(() => {
    // Always restore to top on route change (unless hash is provided)
    if (!location.hash) {
      window.scrollTo({ top: 0, left: 0, behavior: prefersReducedMotion() ? "auto" : "smooth" });
      return;
    }

    const id = location.hash.replace("#", "");
    // Wait for route content to render
    const t = window.setTimeout(() => {
      const el = document.getElementById(id);
      if (!el) return;
      const y = el.getBoundingClientRect().top + window.scrollY - HEADER_OFFSET;
      window.scrollTo({ top: Math.max(0, y), left: 0, behavior: prefersReducedMotion() ? "auto" : "smooth" });
    }, 0);

    return () => window.clearTimeout(t);
  }, [location.pathname, location.hash]);

  return null;
}
