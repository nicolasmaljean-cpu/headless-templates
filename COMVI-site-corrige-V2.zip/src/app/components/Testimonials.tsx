import { Card } from "./ui/card";
import { Star } from "lucide-react";

type Testimonial = {
  name: string;
  role: string;
  location: string;
  quote: string;
};

const TESTIMONIALS: Testimonial[] = [
  {
    name: "S. Martin",
    role: "Restaurant",
    location: "Charleroi",
    quote: "On a enfin du contenu qui donne envie. Les vidéos font pro et on gagne un temps fou.",
  },
  {
    name: "A. Dupont",
    role: "Artisan",
    location: "Hainaut",
    quote: "Ils ont compris mon métier. Les formats courts montrent le savoir-faire sans blabla.",
  },
  {
    name: "N. Leroy",
    role: "PME B2B",
    location: "Bruxelles",
    quote: "La régularité et la cohérence ont changé l’image. Les prospects arrivent mieux qualifiés.",
  },
  {
    name: "C. Petit",
    role: "Coach",
    location: "Wallonie",
    quote: "Simple, rapide, carré. J’ai validé en 2 clics, et tout le calendrier a suivi.",
  },
  {
    name: "M. Bernard",
    role: "Événementiel",
    location: "Namur",
    quote: "Le recap est sorti vite et il a tourné. On s’en sert encore pour vendre l’édition suivante.",
  },
  {
    name: "L. Simon",
    role: "Commerce local",
    location: "Charleroi",
    quote: "Le contenu est clair, punchy, et surtout réutilisable. Ça se voit sur la fréquentation.",
  },
];

export function Testimonials() {
  return (
    <section className="py-24 bg-[#121212] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h2 className="mb-3">Ils nous font confiance</h2>
          <p className="text-slate-300 max-w-2xl">
            Le plus important pour une PME : se sentir compris, gagner du temps, et voir du concret.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <Card key={t.name + t.location} className="bg-white/5 border-white/10 text-white p-6 rounded-2xl">
              <div className="flex gap-1 mb-4" aria-label="Avis 5 étoiles">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-[#cfc7bc]" fill="#cfc7bc" />
                ))}
              </div>

              <p className="text-slate-200 leading-relaxed mb-6">“{t.quote}”</p>

              <div className="text-sm">
                <div className="font-semibold text-white">{t.name}</div>
                <div className="text-slate-400">{t.role} • {t.location}</div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
