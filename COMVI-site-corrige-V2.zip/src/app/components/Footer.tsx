import { Facebook, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";
import { Logo } from "./Logo";
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-[#1a1a1a] text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="mb-4">
              <Logo variant="full" alt="COMVI" className="h-12 mb-4" />
            </div>
            <p className="text-slate-400 mb-4">
              Agence de communication spécialisée en vidéo et marketing digital à Charleroi.
            </p>

            <div className="flex gap-3">
              <a
                href="#"
                aria-label="LinkedIn"
                className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                aria-label="Instagram"
                className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                aria-label="Facebook"
                className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white mb-4 font-semibold">Services</h3>
            <ul className="space-y-2">
              <li><Link to={{ pathname: "/", hash: "#services" }} className="hover:text-[#cfc7bc] transition-colors">Production vidéo</Link></li>
              <li><Link to={{ pathname: "/", hash: "#services" }} className="hover:text-[#cfc7bc] transition-colors">Marketing digital</Link></li>
              <li><Link to={{ pathname: "/", hash: "#services" }} className="hover:text-[#cfc7bc] transition-colors">Relations presse</Link></li>
              <li><Link to={{ pathname: "/", hash: "#services" }} className="hover:text-[#cfc7bc] transition-colors">Médias locaux</Link></li>
              <li><Link to={{ pathname: "/", hash: "#services" }} className="hover:text-[#cfc7bc] transition-colors">Talents à la mission</Link></li>
            </ul>
          </div>

          {/* Entreprise */}
          <div>
            <h3 className="text-white mb-4 font-semibold">Entreprise</h3>
            <ul className="space-y-2">
              <li><Link to="/realisations" className="hover:text-[#cfc7bc] transition-colors">Réalisations</Link></li>
              <li><Link to={{ pathname: "/", hash: "#process" }} className="hover:text-[#cfc7bc] transition-colors">Notre méthode</Link></li>
              <li><Link to={{ pathname: "/", hash: "#faq" }} className="hover:text-[#cfc7bc] transition-colors">FAQ</Link></li>
              <li><Link to={{ pathname: "/", hash: "#contact" }} className="hover:text-[#cfc7bc] transition-colors">Démarrer un projet</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white mb-4 font-semibold">Contact</h3>
            <ul className="space-y-3 text-slate-400">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <a href="mailto:contact@comvi.be" className="hover:text-[#cfc7bc] transition-colors">contact@comvi.be</a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <span>+32 XX XX XX XX</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>Charleroi, Belgique</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-[#2a2a2a] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400">© 2026 COMVI. Tous droits réservés.</p>
          <div className="flex gap-6 text-slate-400">
            <a href="#" className="hover:text-[#cfc7bc] transition-colors">Mentions légales</a>
            <a href="#" className="hover:text-[#cfc7bc] transition-colors">Politique de confidentialité</a>
            <a href="#" className="hover:text-[#cfc7bc] transition-colors">CGV</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
