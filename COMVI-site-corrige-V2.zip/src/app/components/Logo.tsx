import logoUrl from "../../assets/comvi-logo.svg";
import markUrl from "../../assets/comvi-mark.svg";

type LogoProps = {
  variant?: "full" | "mark";
  className?: string;
  alt?: string;
};

/**
 * Local SVG logo to avoid figma:asset URLs breaking in production.
 */
export function Logo({ variant = "full", className = "", alt = "COMVI" }: LogoProps) {
  const src = variant === "mark" ? markUrl : logoUrl;
  return <img src={src} alt={alt} className={className} loading="eager" decoding="async" />;
}
