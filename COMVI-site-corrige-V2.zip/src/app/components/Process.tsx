import { MessageSquare, Lightbulb, Rocket, BarChart } from "lucide-react";

const steps = [
  {
    icon: MessageSquare,
    number: "01",
    title: "On écoute vos besoins",
    description: "Échange pour comprendre vos objectifs, votre cible et vos contraintes. Pas de vente forcée, juste de l'écoute."
  },
  {
    icon: Lightbulb,
    number: "02",
    title: "On construit la stratégie",
    description: "On définit ensemble le plan d'action : contenu, formats, calendrier, canaux. Tout est clair avant de démarrer."
  },
  {
    icon: Rocket,
    number: "03",
    title: "On produit et on diffuse",
    description: "Notre équipe et notre réseau de talents se mettent en action. Vous validez, on ajuste, on lance."
  },
  {
    icon: BarChart,
    number: "04",
    title: "On mesure et on optimise",
    description: "Suivi régulier des résultats. On adapte la stratégie selon ce qui fonctionne vraiment."
  }
];

export function Process() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 data-reveal className="mb-4">Comment on travaille ensemble</h2>
          <p data-reveal data-reveal-delay="70" className="text-slate-600 max-w-2xl mx-auto">
            Un process simple et transparent. Vous savez toujours où vous en êtes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon;
            
            return (
              <div key={index} className="relative" data-reveal data-reveal-delay={String(90 + index * 60)}>
                {/* Connecting line - hidden on last item and on mobile */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-12 left-[calc(50%+2rem)] w-[calc(100%-2rem)] h-0.5 bg-[#cfc7bc]/30"></div>
                )}
                
                <div className="relative bg-white">
                  <div className="flex flex-col items-center text-center">
                    <div className="relative mb-4">
                      <div className="w-24 h-24 bg-gradient-to-br from-[#cfc7bc] to-[#bfb7ac] rounded-full flex items-center justify-center shadow-lg">
                        <Icon className="w-10 h-10 text-[#1a1a1a]" />
                      </div>
                      <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-[#1a1a1a] rounded-full flex items-center justify-center border-4 border-white">
                        <span className="text-white">{step.number}</span>
                      </div>
                    </div>
                    
                    <h3 className="mb-3">{step.title}</h3>
                    <p className="text-slate-600">{step.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Info box */}
        <div data-reveal data-reveal-delay="260" className="mt-16 bg-slate-50 border border-slate-200 rounded-lg p-8 max-w-3xl mx-auto">
          <h3 className="mb-4">Ce qu'on a besoin de votre côté</h3>
          <ul className="space-y-3 text-slate-600">
            <li className="flex items-start gap-3">
              <span className="text-[#1a1a1a] mt-1">→</span>
              <span>Vos objectifs et votre cible (on vous aide à clarifier si besoin)</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#1a1a1a] mt-1">→</span>
              <span>Accès à votre identité visuelle (logo, couleurs, charte si vous en avez)</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#1a1a1a] mt-1">→</span>
              <span>Disponibilité pour valider les contenus (on s'adapte à votre rythme)</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#1a1a1a] mt-1">→</span>
              <span>Feedback régulier pour qu'on reste alignés sur vos attentes</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}