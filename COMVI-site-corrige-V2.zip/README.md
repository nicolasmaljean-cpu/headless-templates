
  # Client-Focused Website Content

  This is a code bundle for Client-Focused Website Content. The original project is available at https://www.figma.com/design/Ppz20vuGQ7ohD69oqxcYuN/Client-Focused-Website-Content.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  