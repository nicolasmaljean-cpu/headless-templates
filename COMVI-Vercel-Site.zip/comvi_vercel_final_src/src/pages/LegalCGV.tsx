export default function LegalCGV() {
  return (
    <section className="section">
      <div className="container">
        <h1 className="h2">Conditions générales (CGV)</h1>
        <p className="small" style={{ marginTop: 12 }}>
          À compléter selon votre offre : modalités de paiement, livraison, droits d’utilisation, retours, etc.
        </p>
      </div>
    </section>
  );
}
