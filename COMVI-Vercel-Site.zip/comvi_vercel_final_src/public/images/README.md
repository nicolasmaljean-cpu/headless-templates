# Dossier images COMVI (à remplir)

Ce projet est livré sans images pour rester léger.
Ajoute tes fichiers ici en gardant ces noms (tu peux remplacer plus tard sans toucher au code).

## Logo
- `logo-comvi.png` (logo principal, fond transparent recommandé)
- `logo-comvi-on-white.png` (optionnel, si tu as une version fond blanc)

## Open Graph / partage
- `og-comvi.png` (1200x630)

## Réalisations (miniatures)
Place tes thumbnails ici :
- `realisations/aftermovie.jpg`
- `realisations/produit.jpg`
- `realisations/entreprise.jpg`
- `realisations/service.jpg`

## Photos (optionnel)
- `charleroi/beffroi.jpg`
- `equipe/equipe-1.jpg`, `equipe/equipe-2.jpg`
